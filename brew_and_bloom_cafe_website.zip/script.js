// Mobile navigation
const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');

menuToggle.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.textContent = isOpen ? '×' : '☰';
});

// Close mobile navigation after selecting a section
navLinks.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.textContent = '☰';
  });
});

// Menu category filters
const filterButtons = document.querySelectorAll('.tab');
const menuCards = document.querySelectorAll('.menu-card');

filterButtons.forEach((button) => {
  button.addEventListener('click', () => {
    filterButtons.forEach((item) => item.classList.remove('active'));
    button.classList.add('active');

    const selectedCategory = button.dataset.filter;
    menuCards.forEach((card) => {
      card.hidden = selectedCategory !== 'all' &&
        card.dataset.category !== selectedCategory;
    });
  });
});

// Dynamic footer year
document.getElementById('year').textContent = new Date().getFullYear();

// Demo interaction for the order call-to-action
document.querySelector('.nav-cta').addEventListener('click', () => {
  const toast = document.getElementById('toast');
  toast.textContent = 'Thanks for visiting! Online ordering is a demo feature.';
  toast.classList.add('show');
  window.setTimeout(() => toast.classList.remove('show'), 2800);
});
